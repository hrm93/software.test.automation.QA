package com.contactservice;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Manages a collection of contacts and provides operations to add, delete, update, and retrieve contacts.
 *
 * This class encapsulates the functionality to manage contacts, including adding, deleting,
 * updating, and retrieving contact information. It uses a concurrent hash map to store contacts,
 * ensuring thread safety during concurrent operations.
 *
 * Operations provided by this class:
 * - Adding a new contact, ensuring no duplicate contact IDs.
 * - Deleting a contact by its unique contact ID.
 * - Updating contact details selectively (only fields that are not null are updated).
 * - Retrieving a contact by its contact ID.
 *
 * Error handling:
 * - Throws IllegalArgumentException when attempting to add a contact with an existing contact ID,
 *   delete a non-existent contact, update a non-existent contact, or perform operations with invalid parameters.
 *
 * Logging:
 * - Uses Java's logging framework to log important events such as contact additions, deletions, updates,
 *   and errors encountered during operations.
 *
 * Usage:
 * - Create an instance of ContactService and use its methods to manage contacts within an application.
 * - Ensure thread safety when accessing and modifying contacts concurrently by leveraging the concurrent map.
 *
 * @author Hannah Rose Morgenstein
 * @version 1.0
 * @since 2024-06-16
 */
public class ContactService {

    private final Map<String, Contact> contacts = new ConcurrentHashMap<>();
    private static final Logger LOGGER = Logger.getLogger(ContactService.class.getName());

    /**
     * Adds a new contact to the service.
     *
     * @param contact The contact to add.
     * @throws IllegalArgumentException If the contact ID already exists in the service.
     */
    public void addContact(Contact contact) {
        String contactId = contact.getContactId();
        if (contacts.containsKey(contactId)) {
            String errorMessage = "Contact ID already exists: " + contactId;
            LOGGER.log(Level.SEVERE, errorMessage);
            throw new IllegalArgumentException(errorMessage);
        }
        contacts.put(contactId, contact);
        LOGGER.log(Level.INFO, "Contact added: {0}", contactId);
    }

    /**
     * Deletes a contact from the service by its contact ID.
     *
     * @param contactId The ID of the contact to delete.
     * @throws IllegalArgumentException If the contact ID does not exist in the service.
     */
    public void deleteContact(String contactId) {
        if (!contacts.containsKey(contactId)) {
            String errorMessage = "Contact ID does not exist: " + contactId;
            LOGGER.log(Level.SEVERE, errorMessage);
            throw new IllegalArgumentException(errorMessage);
        }
        contacts.remove(contactId);
        LOGGER.log(Level.INFO, "Contact deleted: {0}", contactId);
    }

    /**
     * Updates the details of a contact identified by its contact ID.
     * Only updates fields that are not null.
     *
     * @param contactId The ID of the contact to update.
     * @param firstName The new first name (nullable).
     * @param lastName The new last name (nullable).
     * @param phone The new phone number (nullable).
     * @param address The new address (nullable).
     * @throws IllegalArgumentException If the contact ID does not exist in the service.
     */
    public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        Contact contact = contacts.get(contactId);
        if (contact == null) {
            String errorMessage = "Contact ID does not exist: " + contactId;
            LOGGER.log(Level.SEVERE, errorMessage);
            throw new IllegalArgumentException(errorMessage);
        }
        if (firstName != null) contact.setFirstName(firstName);
        if (lastName != null) contact.setLastName(lastName);
        if (phone != null) contact.setPhone(phone);
        if (address != null) contact.setAddress(address);
        LOGGER.log(Level.INFO, "Contact updated: {0}", contactId);
    }

    /**
     * Retrieves a contact from the service by its contact ID.
     *
     * @param contactId The ID of the contact to retrieve.
     * @return The contact object associated with the provided ID, or null if not found.
     */
    public Contact getContactById(String contactId) {
        return contacts.get(contactId);
    }
}
