package com.contactservice.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.contactservice.Contact;
import com.contactservice.ContactService;

import java.util.logging.Logger;

/**
 * Unit tests for the Contact class to verify its behavior under various conditions.
 *
 * This class contains unit tests for the Contact class, validating its behavior
 * when creating contacts with valid and invalid parameters. Each test case focuses
 * on different scenarios such as valid contact creation, null or invalid inputs,
 * and boundary conditions for contact ID, first name, last name, phone number, and address.
 *
 * Test Cases:
 * - Valid contact creation with all fields within valid ranges.
 * - Creating a contact with null or invalid contact ID, first name, last name, phone number, or address.
 * - Ensures that appropriate IllegalArgumentExceptions are thrown when inputs are invalid.
 *
 * Logging:
 * - Uses Java's logging framework to log test execution and any errors encountered.
 *
 * Usage:
 * - Run each test method independently to validate Contact class behavior under specific conditions.
 *
 * @author Hannah Rose Morgenstein
 * @version 1.0
 * @since 2024-06-16
 */
public class ContactTest {

    private static final Logger LOGGER = Logger.getLogger(ContactTest.class.getName());
    /**
     * Setup method to initialize any necessary resources before each test.
     */
    @BeforeEach
    public void setUp() {
        new ContactService();
    }

    /**
     * Test case: Valid contact creation with all fields within valid ranges.
     * Verifies that a contact can be created successfully.
     */
    @Test
    public void testValidContactCreation() {
        LOGGER.info("Running test: testValidContactCreation");
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        assertEquals("1234567890", contact.getContactId());
        assertEquals("John", contact.getFirstName());
        assertEquals("Doe", contact.getLastName());
        assertEquals("1234567890", contact.getPhone());
        assertEquals("123 Main St", contact.getAddress());
    }

    /**
     * Test case: Creating a contact with a null contact ID should throw an IllegalArgumentException.
     */
    @Test
    public void testContactIdNullThrowsException() {
        LOGGER.info("Running test: testContactIdNullThrowsException");
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "John", "Doe", "1234567890", "123 Main St"));
    }

    /**
     * Test case: Creating a contact with a contact ID longer than 10 characters should throw an IllegalArgumentException.
     */
    @Test
    public void testContactIdTooLongThrowsException() {
        LOGGER.info("Running test: testContactIdTooLongThrowsException");
        assertThrows(IllegalArgumentException.class, () -> new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St"));
    }

    /**
     * Test case: Creating a contact with a null first name should throw an IllegalArgumentException.
     */
    @Test
    public void testFirstNameNullThrowsException() {
        LOGGER.info("Running test: testFirstNameNullThrowsException");
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", null, "Doe", "1234567890", "123 Main St"));
    }

    /**
     * Test case: Creating a contact with a first name longer than 10 characters should throw an IllegalArgumentException.
     */
    @Test
    public void testFirstNameTooLongThrowsException() {
        LOGGER.info("Running test: testFirstNameTooLongThrowsException");
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "John1234567", "Doe", "1234567890", "123 Main St"));
    }

    /**
     * Test case: Creating a contact with a null last name should throw an IllegalArgumentException.
     */
    @Test
    public void testLastNameNullThrowsException() {
        LOGGER.info("Running test: testLastNameNullThrowsException");
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "John", null, "1234567890", "123 Main St"));
    }

    /**
     * Test case: Creating a contact with a last name longer than 10 characters should throw an IllegalArgumentException.
     */
    @Test
    public void testLastNameTooLongThrowsException() {
        LOGGER.info("Running test: testLastNameTooLongThrowsException");
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "John", "Doe12345678", "1234567890", "123 Main St"));
    }

    /**
     * Test case: Creating a contact with a null phone number should throw an IllegalArgumentException.
     */
    @Test
    public void testPhoneNullThrowsException() {
        LOGGER.info("Running test: testPhoneNullThrowsException");
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "John", "Doe", null, "123 Main St"));
    }

    /**
     * Test case: Creating a contact with a phone number that is not exactly 10 digits should throw an IllegalArgumentException.
     */
    @Test
    public void testPhoneNotTenDigitsThrowsException() {
        LOGGER.info("Running test: testPhoneNotTenDigitsThrowsException");
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "John", "Doe", "123", "123 Main St"));
    }

    /**
     * Test case: Creating a contact with a null address should throw an IllegalArgumentException.
     */
    @Test
    public void testAddressNullThrowsException() {
        LOGGER.info("Running test: testAddressNullThrowsException");
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "John", "Doe", "1234567890", null));
    }

    /**
     * Test case: Creating a contact with an address longer than 30 characters should throw an IllegalArgumentException.
     */
    @Test
    public void testAddressTooLongThrowsException() {
        LOGGER.info("Running test: testAddressTooLongThrowsException");
        assertThrows(IllegalArgumentException.class, () -> new Contact("1234567890", "John", "Doe", "1234567890", "1234567890123456789012345678901"));
    }

    // Additional test scenarios can be added here to cover edge cases
}
