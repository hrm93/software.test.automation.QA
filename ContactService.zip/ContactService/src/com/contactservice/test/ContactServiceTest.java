package com.contactservice.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.contactservice.Contact;
import com.contactservice.ContactService;

import java.util.logging.Logger;

/**
 * Unit tests for the ContactService class to verify its behavior under various conditions.
 *
 * This class contains unit tests for the ContactService class, focusing on testing
 * operations such as adding, deleting, updating, and retrieving contacts. Each test case
 * validates the expected behavior of ContactService methods under normal and exceptional
 * conditions.
 *
 * Test Cases:
 * - Adding a valid contact and verifying it can be retrieved by ID.
 * - Attempting to add a contact with an existing ID should throw an IllegalArgumentException.
 * - Deleting a contact and ensuring it no longer exists in the service.
 * - Attempting to delete a non-existent contact should throw an IllegalArgumentException.
 * - Updating a contact's fields (first name, last name, phone number, address) and verifying changes.
 * - Attempting to update a non-existent contact or with invalid data should throw an IllegalArgumentException.
 * - Adding contacts with maximum allowed lengths for fields (contact ID, first name, last name, phone number, address).
 *
 * Logging:
 * - Uses Java's logging framework to log setup, teardown, and test execution information.
 *
 * Usage:
 * - Run each test method independently to validate ContactService behavior under specific scenarios.
 *
 * @author Hannah Rose Morgenstein
 * @version 1.0
 * @since 2024-06-16
 */
public class ContactServiceTest {

    private static final Logger LOGGER = Logger.getLogger(ContactServiceTest.class.getName());

    private ContactService contactService;

    /**
     * Setup method to initialize a new ContactService instance before each test.
     */
    @BeforeEach
    public void setUp() {
        contactService = new ContactService();
        LOGGER.info("Setting up ContactService for testing.");
    }

    /**
     * Teardown method to clean up any resources after each test (if needed).
     */
    @AfterEach
    public void tearDown() {
        LOGGER.info("Cleaning up after ContactService tests.");
        // Clean up any state after each test if needed
    }

    /**
     * Test case: Adding a valid contact and verifying it can be retrieved by ID.
     */
    @Test
    public void testAddContact() {
        LOGGER.info("Running test: testAddContact");
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContactById("1234567890"));
    }

    /**
     * Test case: Adding a contact with an existing ID should throw an IllegalArgumentException.
     */
    @Test
    public void testAddContactWithExistingIdThrowsException() {
        LOGGER.info("Running test: testAddContactWithExistingIdThrowsException");
        Contact contact1 = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        Contact contact2 = new Contact("1234567890", "Jane", "Smith", "0987654321", "456 Elm St");
        contactService.addContact(contact1);
        assertThrows(IllegalArgumentException.class, () -> contactService.addContact(contact2));
    }

    /**
     * Test case: Deleting a contact and verifying it no longer exists in the service.
     */
    @Test
    public void testDeleteContact() {
        LOGGER.info("Running test: testDeleteContact");
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.deleteContact("1234567890");
        assertNull(contactService.getContactById("1234567890"));
    }

    /**
     * Test case: Deleting a non-existent contact should throw an IllegalArgumentException.
     */
    @Test
    public void testDeleteContactNonExistentThrowsException() {
        LOGGER.info("Running test: testDeleteContactNonExistentThrowsException");
        assertThrows(IllegalArgumentException.class, () -> contactService.deleteContact("nonexistent"));
    }

    /**
     * Test case: Updating a contact's first name and verifying the change.
     */
    @Test
    public void testUpdateContactFirstName() {
        LOGGER.info("Running test: testUpdateContactFirstName");
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContact("1234567890", "Jane", null, null, null);
        assertEquals("Jane", contactService.getContactById("1234567890").getFirstName());
    }

    /**
     * Test case: Updating a contact's last name and verifying the change.
     */
    @Test
    public void testUpdateContactLastName() {
        LOGGER.info("Running test: testUpdateContactLastName");
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContact("1234567890", null, "Smith", null, null);
        assertEquals("Smith", contactService.getContactById("1234567890").getLastName());
    }

    /**
     * Test case: Updating a contact's phone number and verifying the change.
     */
    @Test
    public void testUpdateContactPhone() {
        LOGGER.info("Running test: testUpdateContactPhone");
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContact("1234567890", null, null, "0987654321", null);
        assertEquals("0987654321", contactService.getContactById("1234567890").getPhone());
    }

    /**
     * Test case: Updating a contact's address and verifying the change.
     */
    @Test
    public void testUpdateContactAddress() {
        LOGGER.info("Running test: testUpdateContactAddress");
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContact("1234567890", null, null, null, "987 Elm St");
        assertEquals("987 Elm St", contactService.getContactById("1234567890").getAddress());
    }

    /**
     * Test case: Updating a non-existent contact should throw an IllegalArgumentException.
     */
    @Test
    public void testUpdateContactNonExistentThrowsException() {
        LOGGER.info("Running test: testUpdateContactNonExistentThrowsException");
        assertThrows(IllegalArgumentException.class, () -> contactService.updateContact("nonexistent", "Jane", "Smith", "0987654321", "987 Elm St"));
    }

    /**
     * Test case: Updating a contact with an invalid phone number format should throw an IllegalArgumentException.
     */
    @Test
    public void testUpdateContactWithInvalidPhoneFormat() {
        LOGGER.info("Running test: testUpdateContactWithInvalidPhoneFormat");
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertThrows(IllegalArgumentException.class, () -> contactService.updateContact("1234567890", null, "Smith", "123", "987 Elm St"));
    }

    /**
     * Test case: Adding a contact with maximum allowed lengths for all fields.
     */
    @Test
    public void testAddContactMaxBoundary() {
        LOGGER.info("Running test: testAddContactMaxBoundary");
        Contact contact = new Contact("1234567890", "Johnabcdef", "Doeabcdefg", "1234567890", "123456789012345678901234567890");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContactById("1234567890"));
    }

    /**
     * Test case: Adding a contact with maximum allowed length for last name.
     */
    @Test
    public void testAddContactWithMaxBoundaryLastName() {
        LOGGER.info("Running test: testAddContactWithMaxBoundaryLastName");
        Contact contact = new Contact("1234567890", "John", "Doeabcdefg", "1234567890", "123 Main St");
        contactService.addContact(contact);
        assertEquals(contact, contactService.getContactById("1234567890"));
    }

    /**
     * Test case: Updating a contact with maximum allowed length for address.
     */
    @Test
    public void testUpdateContactWithMaxBoundaryAddress() {
        LOGGER.info("Running test: testUpdateContactWithMaxBoundaryAddress");
        Contact contact = new Contact("1234567890", "John", "Doe", "1234567890", "123 Main St");
        contactService.addContact(contact);
        contactService.updateContact("1234567890", null, null, null, "123456789012345678901234567890");
        assertEquals("123456789012345678901234567890", contactService.getContactById("1234567890").getAddress());
    }

    // Add more tests as needed...
}
