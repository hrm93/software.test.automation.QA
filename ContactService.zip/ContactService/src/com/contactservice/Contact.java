package com.contactservice;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Represents a contact with basic information such as name, phone number, and address.
 * Provides validations for contact ID, first name, last name, phone number, and address.
 *
 * This class encapsulates the properties and behaviors of a contact entity, ensuring that
 * all fields are validated upon creation and updates. It includes methods to retrieve and
 * modify each attribute, while enforcing constraints on their formats and lengths.
 *
 * The validations cover requirements such as:
 * - Contact ID: Must be non-null and up to 10 characters long.
 * - First and Last Names: Must be non-null, alphabetic, and up to 10 characters long.
 * - Phone Number: Must be exactly 10 digits.
 * - Address: Must be non-null and up to 30 characters long.
 *
 * Logging is utilized to record validation failures, providing insights into errors encountered
 * during object construction and attribute updates.
 *
 * @author Hannah Rose Morgenstein
 * @version 1.0
 * @since 2024-06-16
 */
public class Contact {

    private static final Logger LOGGER = Logger.getLogger(Contact.class.getName());

    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    /**
     * Constructs a Contact object with specified details.
     * Validates the input parameters to ensure they meet requirements.
     *
     * @param contactId The unique ID of the contact (must not be null and at most 10 characters long).
     * @param firstName The first name of the contact (must not be null, alphabetic, and at most 10 characters long).
     * @param lastName The last name of the contact (must not be null, alphabetic, and at most 10 characters long).
     * @param phone The phone number of the contact (must not be null and exactly 10 digits).
     * @param address The address of the contact (must not be null and at most 30 characters long).
     * @throws IllegalArgumentException If any parameter does not meet validation criteria.
     */
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        validateContactId(contactId);
        validateName(firstName, "First name");
        validateName(lastName, "Last name");
        validatePhone(phone);
        validateAddress(address);

        this.contactId = contactId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.phone = phone;
        this.address = address;

        LOGGER.log(Level.INFO, "New contact created with ID: {0}", contactId);
    }

    /**
     * Validates the contact ID ensuring it is not null and within the length limit.
     *
     * @param contactId The contact ID to validate.
     * @throws IllegalArgumentException If contactId is null or exceeds 10 characters.
     */
    private void validateContactId(String contactId) {
        if (contactId == null || contactId.length() > 10) {
            String errorMessage = "Contact ID must not be null and must be at most 10 characters long.";
            LOGGER.log(Level.SEVERE, errorMessage);
            throw new IllegalArgumentException(errorMessage);
        }
    }

    /**
     * Validates a name ensuring it is not null, consists only of alphabetic characters,
     * and is within the length limit.
     *
     * @param name The name to validate.
     * @param fieldName The name of the field being validated (for error messages).
     * @throws IllegalArgumentException If name is null, contains non-alphabetic characters, or exceeds 10 characters.
     */
    private void validateName(String name, String fieldName) {
        if (name == null || !name.matches("[a-zA-Z]+") || name.length() > 10) {
            String errorMessage = fieldName + " must not be null, must contain only alphabetic characters, and must be at most 10 characters long.";
            LOGGER.log(Level.SEVERE, errorMessage);
            throw new IllegalArgumentException(errorMessage);
        }
    }

    /**
     * Validates the phone number ensuring it is not null and consists of exactly 10 digits.
     *
     * @param phone The phone number to validate.
     * @throws IllegalArgumentException If phone is null or does not consist of exactly 10 digits.
     */
    private void validatePhone(String phone) {
        if (phone == null || !phone.matches("\\d{10}")) {
            String errorMessage = "Phone number must not be null and must be exactly 10 digits.";
            LOGGER.log(Level.SEVERE, errorMessage);
            throw new IllegalArgumentException(errorMessage);
        }
    }

    /**
     * Validates the address ensuring it is not null and within the length limit.
     *
     * @param address The address to validate.
     * @throws IllegalArgumentException If address is null or exceeds 30 characters.
     */
    private void validateAddress(String address) {
        if (address == null || address.length() > 30) {
            String errorMessage = "Address must not be null and must be at most 30 characters long.";
            LOGGER.log(Level.SEVERE, errorMessage);
            throw new IllegalArgumentException(errorMessage);
        }
    }

    /**
     * Retrieves the contact ID.
     *
     * @return The contact ID.
     */
    public String getContactId() {
        return contactId;
    }

    /**
     * Retrieves the first name.
     *
     * @return The first name.
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the first name after validating it.
     *
     * @param firstName The new first name to set.
     * @throws IllegalArgumentException If firstName is null, contains non-alphabetic characters, or exceeds 10 characters.
     */
    public void setFirstName(String firstName) {
        validateName(firstName, "First name");
        this.firstName = firstName;
    }

    /**
     * Retrieves the last name.
     *
     * @return The last name.
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the last name after validating it.
     *
     * @param lastName The new last name to set.
     * @throws IllegalArgumentException If lastName is null, contains non-alphabetic characters, or exceeds 10 characters.
     */
    public void setLastName(String lastName) {
        validateName(lastName, "Last name");
        this.lastName = lastName;
    }

    /**
     * Retrieves the phone number.
     *
     * @return The phone number.
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Sets the phone number after validating it.
     *
     * @param phone The new phone number to set.
     * @throws IllegalArgumentException If phone is null or does not consist of exactly 10 digits.
     */
    public void setPhone(String phone) {
        validatePhone(phone);
        this.phone = phone;
    }

    /**
     * Retrieves the address.
     *
     * @return The address.
     */
    public String getAddress() {
        return address;
    }

    /**
     * Sets the address after validating it.
     *
     * @param address The new address to set.
     * @throws IllegalArgumentException If address is null or exceeds 30 characters.
     */
    public void setAddress(String address) {
        validateAddress(address);
        this.address = address;
    }
}
